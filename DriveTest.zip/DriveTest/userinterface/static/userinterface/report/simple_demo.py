import pdfkit
pdfkit.from_file('report.html','out1.pdf')
