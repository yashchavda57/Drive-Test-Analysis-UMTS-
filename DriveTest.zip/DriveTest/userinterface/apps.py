from django.apps import AppConfig


class UserinterfaceConfig(AppConfig):
    name = 'userinterface'
